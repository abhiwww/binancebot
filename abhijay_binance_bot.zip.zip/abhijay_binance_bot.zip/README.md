# Binance Futures Trading Bot

A CLI-based trading bot for Binance USDT-M Futures.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt